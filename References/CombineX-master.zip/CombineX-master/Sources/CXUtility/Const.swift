public enum Const {
    
    public static let nsec_per_sec = 1000_000_000
    public static let nsec_per_msec = 1000_000
    public static let nsec_per_usec = 1000
    
    public static let usec_per_sec = 1000_000
    public static let usec_per_msec = 1000
    
    public static let msec_per_sec = 1000
}
