/// A namespace for types related to the `Subscriber` protocol.
public enum Subscribers {
}
