//
//  Vendor.swift
//  VendorCatalog-SwiftUI
//
//  Created by Kevin Barney on 6/25/20.
//

import Foundation

struct Vendor: Identifiable {
    let id = UUID()
    let title: String
    let reviewScore: Int
    let reviewCount: Int
    let categoryName: String
    let locationName: String
    let description: String
    let minGuests: Int
    let maxGuests: Int
    let isSpotlight: Bool
    let photoCount: Int
    let videoCount: Int
    let imageName: String
    let has3DTour: Bool

    var caption: String {
        return "\(reviewCount) Reviews • \(categoryName) • \(locationName)"
    }
}

let testData = [
    Vendor(title: "Historic Rosemont Manor",
           reviewScore: 5,
           reviewCount: 93,
           categoryName: "Historic Weddings",
           locationName: "Berryville, VA",
           description: "Getting married? Don't miss out on teh Historic Rosemont's 5th annual bridal show - \"I Thee Wed\" on Sunday, July 26th from noon - 5pm.",
           minGuests: 2,
           maxGuests: 500,
           isSpotlight: true,
           photoCount: 34,
           videoCount: 1,
           imageName: "Vendor1",
           has3DTour: true),
    Vendor(title: "Hilton Garden Inn Fairfax",
           reviewScore: 5,
           reviewCount: 171,
           categoryName: "Hotel Weddings",
           locationName: "Fairfax, VA",
           description: "The Hikton Garden Inn Fairfax is a hotel with a ballroom for couple's weddings in the greater Washington, D.C. area. This classic and modern hotel features a bla bla bla",
           minGuests: 2,
           maxGuests: 200,
           isSpotlight: false,
           photoCount: 81,
           videoCount: 2,
           imageName: "Vendor2",
           has3DTour: false),
    Vendor(title: "The Villa",
           reviewScore: 4,
           reviewCount: 61,
           categoryName: "Banquet Halls",
           locationName: "Beltsville, MD",
           description: "The Villa is a banquet hall for couples' weddings in the Washington, D.C. area. This elegantly modern ballroom is built in a Mediterranean style.",
           minGuests: 30,
           maxGuests: 300,
           isSpotlight: false,
           photoCount: 4,
           videoCount: 1,
           imageName: "Vendor3",
           has3DTour: false),
]
