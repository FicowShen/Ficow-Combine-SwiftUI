//
//  VendorCatalogView.swift
//  Shared
//
//  Created by Kevin Barney on 6/25/20.
//

import SwiftUI

struct VendorCatalogView: View {
    var vendors: [Vendor] = []

    var body: some View {
        NavigationView {
            ScrollView {
                LazyVStack(spacing: 10) {
                    VendorCatalogHeader(vendors: vendors)

                    ForEach(vendors)  { vendor in
                        VendorCard(vendor: vendor)
                    }
                }
                .background(Color.init(hue: 0,
                                       saturation: 0,
                                       brightness: 0.9))
            }
            .background(Color.white)
            .edgesIgnoringSafeArea([.leading, .bottom, .trailing])
            .navigationBarTitle(Text("WASHINGTON DC WEDDING VENUES"), displayMode: .inline)
            .navigationBarItems(trailing:
                                    Button(action: {}) {
                                        Text("Filter")
                                            .font(.callout)
                                            .padding([.leading, .trailing], 15)
                                            .padding([.top, .bottom], 4)
                                    }
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color.accentColor, lineWidth: 1)
                                    )
            )

        }
    }
}

private struct VendorCarousel: View {
    let vendors: [Vendor]

    var body: some View {
        ScrollView(.horizontal, showsIndicators: true) {
            LazyHStack(spacing: 20) {
                ForEach(vendors) { vendor in
                    VendorCarouselCard(vendor: vendor)
                }
            }
            .frame(height: 200)
            .padding()
        }
        .background(Color.white)
    }
}

private struct VendorCarouselCard: View {
    let vendor: Vendor

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Image(vendor.imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height: 100)
                .clipped()

            VStack(alignment: .leading, spacing: 2) {
                Text(vendor.title)
                    .lineLimit(2)

                HStack {
                    ReviewStarsView(reviewScore: vendor.reviewScore)
                    Text("\(vendor.reviewCount) Reviews")
                        .foregroundColor(.secondary)
                }
                .font(.caption)
            }

            Spacer()
                .frame(minHeight: 0)

            Button(action: {}) {
                Text("REQUEST PRasdasdfICING")
                    .fontWeight(.semibold)
            }
        }
        .frame(width: 200)
        .padding(.bottom, 8)
    }
}

private struct VendorCard: View {
    let vendor: Vendor

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            VendorCardImageView(vendor: vendor)
            VendorCardContentView(vendor: vendor)
        }.background(Color.white)
    }
}

private struct VendorCardImageView: View {
    let vendor: Vendor

    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Image(vendor.imageName)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(maxHeight: 200)
                .clipped()

            if vendor.isSpotlight {
                VStack(alignment: .leading) {
                    Text("SPOTLIGHT")
                        .font(.callout)
                        .fontWeight(.semibold)
                        .padding(8)
                        .foregroundColor(.white)
                        .background(Color(hue: 0,
                                          saturation: 0,
                                          brightness: 0,
                                          opacity: 0.6))
                        .padding(.top, 8)

                    Spacer()
                }
            }

            MediaView(photoCount: vendor.photoCount,
                      videoCount: vendor.videoCount,
                      has3DTour: vendor.has3DTour)
        }
    }
}

private struct VendorCardContentView: View {
    let vendor: Vendor

    var body: some View {
        VStack(alignment: .leading, spacing: 10.0) {
            VStack(alignment: .leading, spacing: 2.0) {
                Text(vendor.title)
                    .font(.title2)
                    .fontWeight(.semibold)
                    .lineLimit(3)

                HStack(alignment: .top) {
                    ReviewStarsView(reviewScore: vendor.reviewScore)
                    Text(vendor.caption)
                        .foregroundColor(.secondary)
                }
                .font(.caption)
            }

            Text(vendor.description)
                .lineLimit(3)
                .foregroundColor(.secondary)

            VStack(alignment: .leading, spacing: 2) {
                Text("Guests")
                    .font(.callout)
                    .foregroundColor(.secondary)
                HStack {
                    Image(systemName: "person.2")
                    Text("\(vendor.minGuests) to \(vendor.maxGuests)")
                }
            }

            Button(action: {}) {
                HStack {
                    Text("Request Pricing")
                        .fontWeight(.semibold)
                        .foregroundColor(.white)
                }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.accentColor)
            }
        }.padding()
    }
}

private struct ReviewStarsView: View {
    let reviewScore: Int
    var reviewStars: String {
        var reviewStars = ""
        for _ in 0..<reviewScore {
            reviewStars.append("★")
        }
        return reviewStars
    }

    var body: some View {
        Text(reviewStars)
            .fontWeight(.bold)
            .foregroundColor(.yellow)

    }
}

private struct MediaView: View {
    let photoCount: Int
    let videoCount: Int
    let has3DTour: Bool

    var body: some View {
        HStack() {
            Button(action: {}) {

                if photoCount > 0{
                    HStack() {
                        Image(systemName: "photo.on.rectangle.angled")
                        Text("\(photoCount)")
                            .font(.callout)

                    }                             .padding(10)
                    .foregroundColor(.white)
                    .background(Color(hue: 0,
                                      saturation: 0,
                                      brightness: 0,
                                      opacity: 0.6))
                    .clipShape(RoundedRectangle(cornerRadius: 5.0,
                                                style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                }

            }

            if videoCount > 0 {
                Button(action: {}) {
                    HStack() {
                        Image(systemName: "play.rectangle")
                        Text("\(videoCount)")
                            .font(.callout)

                    }                             .padding(10)
                    .foregroundColor(.white)
                    .background(Color(hue: 0,
                                      saturation: 0,
                                      brightness: 0,
                                      opacity: 0.75))
                    .clipShape(RoundedRectangle(cornerRadius: 5.0,
                                                style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                }

            }

            if has3DTour {
                Button(action: {}) {
                    HStack() {
                        Image(systemName: "rotate.3d")
                    }                             .padding(10)
                    .foregroundColor(.white)
                    .background(Color(hue: 0,
                                      saturation: 0,
                                      brightness: 0,
                                      opacity: 0.75))
                    .clipShape(RoundedRectangle(cornerRadius: 5.0,
                                                style: /*@START_MENU_TOKEN@*/.continuous/*@END_MENU_TOKEN@*/))
                }

            }

            Spacer()
        }.padding(8)

    }

}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        VendorCatalogView(vendors: testData)
    }
}

struct FilterButtons: View {
    var body: some View {
        HStack {
            Button(action: {}) {
                Text("Change region")
            }
            .padding([.trailing, .top, .bottom])

            Button(action: {}) {
                Text("Change category")
            }
            .padding([.trailing, .top, .bottom])
        }
        .padding(.leading)
    }
}

struct VendorCatalogHeader: View {
    let vendors: [Vendor]

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            FilterButtons()

            Divider()

            Text("\(vendors.count) vendors")
                .foregroundColor(.secondary)
                .padding([.leading, .top, .bottom])

            Divider()

            VendorCarousel(vendors: vendors)
        }
        .background(Color.white)
    }
}
