//
//  VendorCatalog_SwiftUIApp.swift
//  Shared
//
//  Created by Kevin Barney on 6/25/20.
//

import SwiftUI

@main
struct VendorCatalog_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            VendorCatalogView()
        }
    }
}
